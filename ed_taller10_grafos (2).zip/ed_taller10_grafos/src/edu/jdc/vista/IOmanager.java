package edu.jdc.vista;

import edu.jdc.modelos.Nodo;
import javax.swing.JOptionPane;

/**
 * fecha: 17/octube/2023
 *
 * @author sanni
 */
public class IOmanager {

    //variables globales
    //metodo contructor
    //metodos propios
    public String inputString(String respuesta) {
        String data = JOptionPane.showInputDialog(respuesta);
        return respuesta;
    }

    public String inputint(String variableData) {
        String data = JOptionPane.showInputDialog(variableData);
        return data;
    }

    public String showMenssage(String message) {
        JOptionPane.showMessageDialog(null, "matriz creada");
        return message;
    }

    public Nodo[] showVector(Nodo vector[]) {
        String contenido = "";
        for (int i = 0; i < vector.length; i++) {
            contenido = contenido + vector[i].getValue() + " ";
        }
        JOptionPane.showMessageDialog(null, contenido);
        return vector;

    }
    //metodos get/set

}
