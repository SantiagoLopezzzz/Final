package edu.jdc.controlador;

import edu.jdc.modelos.Graphs;
import edu.jdc.modelos.Nodo;
import edu.jdc.vista.IOmanager;

/**
 * fecha: 17/octube/2023 grafos version 1
 *
 * @author sanni
 */
public class controller {

    //variables globales
    private IOmanager objetoIOmanager;
    private Graphs objetoGraphs;
    private String answer;
    private int numberNodos;
    private Nodo[] vector;
    private String nodoOrigen;
    private String nodoDestino;

    //metodo contructor
    public controller() {
        objetoIOmanager = new IOmanager();
        objetoGraphs = new Graphs();
        answer = "";
    }

    //metodos propios
    public String informationRequest() {
        try {
            numberNodos = Integer.parseInt(objetoIOmanager.inputint("dijite el numero de nodos"));//convercion de string a entero
            answer = objetoGraphs.createMatriz(numberNodos);

        } catch (Exception error) {
        }

        //la eccepcion va aqui try/casch if anidados return
        return objetoIOmanager.showMenssage(answer);
    }

    public String fellMatriz() {
        String maindNodos; //indentificacion nodo
        for (int i = 0; i < numberNodos; i++) {
            maindNodos = objetoIOmanager.inputint("dijite el identificador del nodo"); // imput INT
            objetoGraphs.newNodo(maindNodos);
        }
        answer = "se lleno y creo el vector";
        return objetoIOmanager.showMenssage(answer);
    }

    public Nodo[] vector() {
        Nodo[] vector = objetoGraphs.getNodo0();

        return objetoIOmanager.showVector(vector);
    }

    public String relacionarNodos() {
        int desicion = 0;
        do {
            nodoOrigen = objetoIOmanager.inputString("dijite el vertice de origen");
            nodoDestino = objetoIOmanager.inputString("dijite el vertice de destino");
            answer = objetoGraphs.newArists(nodoOrigen, nodoDestino);
            objetoIOmanager.showMenssage(answer);
            desicion = Integer.parseInt(objetoIOmanager.inputint("digite 1 para ingresar un nuevo dato - dijite dos para salir"));
        } while (desicion == 1);

        return "";

    }

    //solicitar-request        
    public void init() {
        informationRequest();
        fellMatriz();
        relacionarNodos();
    }
    //metodos get/set
}

//las eccepciones van en el controlador
