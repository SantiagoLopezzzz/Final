package edu.jdc.Run;

import edu.jdc.controlador.controller;

/**
 * fecha: 17/octube/2023
 *
 * @author sanni
 */
public class Runner {

    //variables globales
    //metodo contructor
    //metodos propios
    public static void main(String[] args) {
        controller objecto = new controller();
        objecto.init();
    }
    //metodos get/set

}

//verificar si se esta llenando el vector 
// imprimir el vector que se esta haciendo 
