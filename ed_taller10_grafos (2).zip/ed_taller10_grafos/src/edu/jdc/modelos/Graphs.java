package edu.jdc.modelos;

/**
 * fecha: 17/octube/2023
 *
 * @author sanni
 */
public class Graphs {

    //variables globales
    private int matrizAdjacent[][];
    private String answer;
    private int numberNodos;
    private Nodo nodo0[];

    //metodo contructor
    public Graphs() {
        answer = "";
    }

    //metodos propios
    public String createMatriz(int nodos) {
        matrizAdjacent = new int[nodos][nodos];
        nodo0 = new Nodo[nodos];
        for (int i = 0; i < nodos; i++) {
            for (int j = 0; j < nodos; j++) {
                matrizAdjacent[i][j] = 0;
                //numberNodos=0; 
                System.out.print(matrizAdjacent[i][j] + "-");
            }
            System.out.println();
        }
        answer = "matirz creada";
        return answer;
    }

    public void newNodo(String value) {
        Nodo objetoNodo = new Nodo(value);
        nodo0[numberNodos] = objetoNodo;
        numberNodos++;
    }

    // public void buscarPosicicion() {
    // }
    public String newArists(String origen, String destino) {
        int valorOrigen;
        int valorDestino;

        valorOrigen = findPosicicionNode(origen);
        valorDestino = findPosicicionNode(destino);
        if (valorOrigen >= 0 && valorDestino >= 0) {
            matrizAdjacent[valorOrigen][valorDestino] = 1;
            answer = "se creo el nodo";
        } else {
            answer = "el nodo no existe";
        }
        return answer;
    }

    public int findPosicicionNode(String value) {
        for (int i = 0; i < numberNodos; i++) {
            if (nodo0[i].getValue().equals(value)) {
                return i;
            }
        }
        return -1;
    }
    //metodos get/set

    public Nodo[] getNodo0() {
        return nodo0;
    }

    public void setNodo0(Nodo[] nodo0) {
        this.nodo0 = nodo0;
    }

}
