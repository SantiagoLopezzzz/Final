package edu.jdc.modelos;

/**
 * fecha: 17/octube/2023
 *
 * @author sanni
 */
public class Nodo {

    //variables globales
    private String value;

    //metodo contructor
    public Nodo() {
        value = "";// inicializar

    }

    public Nodo(String value) {
        this.value = value;
    }

    //metodos propios sirve para verificar la duplicidad de los nodos (si hay nodos con nombre iguales)
    public boolean nodosIguales(Nodo vertices) {
        return value.equals(vertices.value);//equals permite comparar objetos y strings 
    }

    //metodos get/set
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
